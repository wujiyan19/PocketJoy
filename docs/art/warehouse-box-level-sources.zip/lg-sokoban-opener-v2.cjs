const {solve}=require(process.cwd()+'/scripts/test-sokoban-levels.cjs');
const fs=require('node:fs'), path=require('node:path');
const args=process.argv.slice(2);
const offsets=[-7,1,7,-1], baseLoc = p=>'('+((p%7)+1)+','+(1+Math.floor(p/7))+')';
function parse(rows){const tiles=rows.join(''), boxes=Array.from(tiles).flatMap((v,i)=>v==='$'?[i]:[]);return {p:tiles.indexOf('@'),boxes,tiles};}
function run(rows,blockGoal=false,initial){
  const orig=parse(rows);const tiles=orig.tiles;
  let p=initial?.p??orig.p, bs=initial?.boxes??orig.boxes, visited=new Set();
  const seenPush=new Set(), first=[];let q=[{p,boxes:bs,route:'',pushes:[]}];let solved,at;
  for(let head=0;head<q.length;head++){const state=q[head],{p,boxes,route,pushes}=state, key=p+'|'+boxes.slice().sort().join(',');if(visited.has(key))continue;visited.add(key);
    if(boxes.every(x=>tiles[x]==='.')){solved=route;at=pushes;break;}
    for(let d=0;d<4;d++){const to=p+offsets[d],box=boxes.indexOf(to);if(tiles[to]==='#')continue;
      let b=boxes, ps=pushes;
      if(box!==-1){
        const past=to+offsets[d];if(tiles[past]==='#'||boxes.includes(past)||(blockGoal&&tiles[to]==='.'))continue;
        b=boxes.slice();b[box]=past;ps=[...pushes,[box,to,past,d,tiles[past]==='.']];
        if(pushes.length===0&&!seenPush.has(to+'/'+past)){seenPush.add(to+'/'+past);first.push({p:to,boxes:b,route:route+d});}
      }
      q.push({p:to,boxes:b,route:route+d,pushes:ps});
    }
  }
  return {solved,at,first};
}
const templates=[
['#######','#..   #','###   #','#     #','#     #','#######','#######'],
['#######','#######','#..   #','###   #','#     #','#    ##','#######'],
['#######','#..   #','###   #','#     #','#  #  #','#     #','#######'],
['#######','#..   #','##    #','#     #','#  #  #','#######','#######'],
['#######','#######','#..   #','##    #','#   # #','#     #','#######']];
let seed=190;function rnd(n){seed=(Math.imul(seed,1664525)+1013904223)>>>0;return Math.floor(seed/2**32*n);}
const candidates=fs.readFileSync(path.join(process.env.TEMP,'lg-sokoban-g1-v2.jsonl'),'utf8').trim().split(/\r?\n/).map(r=>JSON.parse(r)).filter(r=>r.pushes>=5&&r.pushes<=8&&r.m>=12&&r.m<=22&&parse(r.rows).boxes.length===2);
for(let it=0;it<400;it++){
const blank=templates[it%5].join('').split('');const free=blank.flatMap((x,i)=>x===' '?[i]:[]);
for(const c of ['@','$','$'])blank[free.splice(rnd(free.length),1)[0]]=c;
const rows=Array.from({length:7},(_,i)=>blank.slice(i*7,i*7+7).join(''));const result=solve(rows);if(result?.distance<12||result?.distance>22||!result)continue;
const pushes=solve(rows,true).distance;if(pushes<5||pushes>8)continue;candidates.push({m:result.distance,pushes,rows});}
let written=0;
for(const b of candidates){
 const result=run(b.rows);if(!result.solved||run(b.rows,true).solved)continue;
 const orig=parse(b.rows);const options=result.first.map(state=>({firstRoute:state.route,to:state.p,beyond:state.boxes.find(x=>!orig.boxes.includes(x)),win:Boolean(run(b.rows,false,state).solved)}));
 if(!options.some(x=>x.win)||!options.some(x=>!x.win))continue;
 console.log(JSON.stringify({...b,route:result.solved,pushesSeries:result.at,options}));if(++written>=20)break;
}
