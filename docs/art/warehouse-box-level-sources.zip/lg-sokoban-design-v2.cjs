const trees = new Map();
const arrows='^>v<';
const deltas=[-7,1,7,-1];
const group=Number(process.argv[2]), budget=Number(process.argv[3]), stageMode=Number(process.argv[4]), baseSeed=Number(process.argv[5]);
let seed=baseSeed;
const random=n=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return Math.floor(seed/2**32*n)};
const take=a=>a.splice(random(a.length),1)[0];
function search(tiles, p, initial, colored, wantPush){
  const seen=new Set(), results=new Map();let now=[[p,initial]], dist=0;
  while(now.length){
    const next=[];
    for(let i=0;i<now.length;i++){
      const [pos,boxes]=now[i];let boxkey=0;
      for(const b of boxes)boxkey=boxkey*64+b;
      let k=boxkey*64+pos;if(seen.has(k))continue;seen.add(k);
      if(!results.has(boxkey))results.set(boxkey,dist);
      for(let d=0;d<4;d++){
        const to=pos+deltas[d];
        if(tiles[to]==='#'||(arrows.includes(tiles[to])&&tiles[to]!==arrows[d]))continue;
        const at=boxes.indexOf(to);let b=boxes;
        if(at>=0){
           const dst=to+deltas[d];
           if(tiles[dst]==='#'||boxes.includes(dst)||(arrows.includes(tiles[dst])&&tiles[dst]!==arrows[d]))continue;
           b=boxes.slice();b[at]=dst;
           if(colored){for(let j=1;j<b.length;j++)for(let k=j+1;k<b.length;k++)if(b[j]>b[k]){const tmp=b[j];b[j]=b[k];b[k]=tmp;}}
           else b.sort((x,y)=>x-y);
        }
        let bk=0;for(const x of b)bk=bk*64+x;
        if(!seen.has(bk*64+to)) ((wantPush&&at<0)?now:next).push([to,b]);
      }
    }
    now=next;dist++;
  }
  return results;
}
function decode(key,n){const b=Array(n);for(let i=n-1;i>=0;i--){b[i]=key%64;key=Math.floor(key/64);}return b;}
function encode(b){return b.reduce((key,x)=>key*64+x,0);}
const prefer=stageMode===0?[5,6,7,8,9,10,11]:stageMode===1?[10,11,12,13,14,15,16,17]:stageMode===2?[15,16,17,18,19,20,21,22,23,24,25,26,27,28]:[18,19,20,21,22,23,24,25,26,27,28,29,30];
const emitted=new Map();
for(let trial=0;trial<budget;trial++){
  const tiles=Array.from('#######'+'#     #'.repeat(5)+'#######');
  let free=tiles.flatMap((s,i)=>s===' '?[i]:[]);
  for(let i=0,n=2+random(6);i<n;i++)tiles[take(free)]='#';
  const n=stageMode===0?(trial%3===0?3:2):(trial%4===0&&stageMode>=2?4:3);
  let fit=free.filter(i=>!((tiles[i-1]==='#'||tiles[i+1]==='#')&&(tiles[i-7]==='#'||tiles[i+7]==='#')));
  if(fit.length<n)continue;
  const boxes=Array.from({length:n},()=>take(fit)); const colored=group>=3;if(!colored)boxes.sort((a,b)=>a-b);else {const tail=boxes.splice(1).sort((a,b)=>a-b);boxes.push(...tail);}
  free=free.filter(x=>!boxes.includes(x));const p=take(free);
  if(group===2||group===4){for(let i=0,n=1+random(2);i<n;i++){const ar=take(free);tiles[ar]=arrows[random(4)];}}
  const allMoves=search(tiles,p,boxes,colored,false);
  if(allMoves.size<20)continue;
  const pushCounts=search(tiles,p,boxes,colored,true);
  let noArrow;
  const candidates=[];
  for(const [key,m] of allMoves){
    const pushes=pushCounts.get(key);
    if(!prefer.includes(pushes)||m<pushes*2||m>pushes*5+10)continue;
    const goals=decode(key,n);
    if(goals.some(g=>tiles[g]!==' '||boxes.includes(g)||g===p))continue;
    let colorDiff=0;
    if(colored){let relaxed=m;for(const prime of goals){const alt=encode([prime,...goals.filter(x=>x!==prime).sort((a,b)=>a-b)]);relaxed=Math.min(relaxed,allMoves.get(alt)??m);}colorDiff=m-relaxed;if(colorDiff<3)continue;}
    let arrowDiff=0;
    if(group===2||group===4){if(!noArrow)noArrow=search(tiles.map(s=>arrows.includes(s)?' ':s),p,boxes,colored,false);arrowDiff=m-noArrow.get(key);if(arrowDiff<3)continue;}
    const range=pushes+'_'+Math.floor(m/7);
    if((emitted.get(range)??0)>=3)continue;
    const b=tiles.slice();for(const [j,g] of goals.entries())b[g]=j===0&&colored?'a':'.';for(const[j,y]of boxes.entries())b[y]=j===0&&colored?'A':'$';b[p]='@';
    candidates.push({pushes,m,arrowDiff,colorDiff,trial,rows:Array.from({length:7},(_,i)=>b.slice(i*7,7*i+7).join('')),range});
  }
  candidates.sort((a,b)=>b.pushes-a.pushes||b.m-a.m);
  let lastPush=0, printed=0;
  for(const cand of candidates){if(cand.pushes===lastPush||printed>=3)continue;lastPush=cand.pushes;printed++;console.log(JSON.stringify(cand));emitted.set(cand.range,(emitted.get(cand.range)||0)+1);}
}
